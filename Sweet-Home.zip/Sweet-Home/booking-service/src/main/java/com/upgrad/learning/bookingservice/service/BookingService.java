package com.upgrad.learning.bookingservice.service;

import com.upgrad.learning.bookingservice.dto.BookingInfo;
import com.upgrad.learning.bookingservice.dto.PaymentInfo;
import com.upgrad.learning.bookingservice.entities.Booking;
import org.springframework.stereotype.Service;

public interface BookingService {
    public Booking acceptBookingDetails(BookingInfo bookingInfo);
    public Booking acceptPaymentDetails(PaymentInfo paymentInfo);
}
