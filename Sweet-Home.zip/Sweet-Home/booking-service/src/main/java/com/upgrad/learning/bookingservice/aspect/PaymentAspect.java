package com.upgrad.learning.bookingservice.aspect;

import com.upgrad.learning.bookingservice.dto.PaymentInfo;
import com.upgrad.learning.bookingservice.entities.Booking;
import com.upgrad.learning.bookingservice.exception.BookingException;
import com.upgrad.learning.bookingservice.repository.BookingRepository;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import java.util.Optional;

@Aspect
@Component
public class PaymentAspect {
    @Autowired
    BookingRepository bookingRepository;
    @Before(value = "execution(* com.upgrad.learning.bookingservice.service.BookingServiceImpl.acceptPaymentDetails(..)) and args(paymentInfo)")
    public void beforeAdvice(JoinPoint joinPoint, PaymentInfo paymentInfo){
        if(!(paymentInfo.getPaymentMode().equalsIgnoreCase("upi") || paymentInfo.getPaymentMode().equalsIgnoreCase("card"))){
            throw new BookingException("Invalid mode of payment", HttpStatus.BAD_REQUEST.value());
        }

        Optional<Booking> booking = bookingRepository.findById(paymentInfo.getBookingId());
        if(booking.isEmpty()){
            throw new BookingException("Invlid Booking Id", HttpStatus.BAD_REQUEST.value());
        }
    }
}
