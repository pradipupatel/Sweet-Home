package com.upgrad.learning.bookingservice.exception;

public class BookingException extends RuntimeException{
    String message;
    int statusCode;


    public BookingException(String message, int statusCode){
        this.message = message;
        this.statusCode = statusCode;
    }

    @Override
    public String toString() {
        return "{" +
                "message='" + message + '\'' +
                ", statusCode=" + statusCode +
                '}';
    }
}
