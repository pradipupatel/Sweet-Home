package com.upgrad.learning.bookingservice.service;

import com.upgrad.learning.bookingservice.dto.BookingInfo;
import com.upgrad.learning.bookingservice.dto.BookingInfoEntity;
import com.upgrad.learning.bookingservice.dto.PaymentInfo;
import com.upgrad.learning.bookingservice.entities.Booking;
import com.upgrad.learning.bookingservice.repository.BookingRepository;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Random;

@Service
public class BookingServiceImpl implements BookingService {
    @Autowired
    BookingRepository bookingRepository;

    @Autowired
    ModelMapper modelMapper;

    @Autowired
    private RestTemplate restTemplate;

    @Value("${payment.url}")
    private String paymentUrl;

    Logger logger = LoggerFactory.getLogger(BookingServiceImpl.class);
    @Override
    public Booking acceptBookingDetails(BookingInfo bookingInfo) {
        BookingInfoEntity bookingInfoEntity = new BookingInfoEntity();
        bookingInfoEntity.setBookedOn(LocalDateTime.now());

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        bookingInfoEntity.setFromDate(LocalDate.parse(bookingInfo.getFromDate(), formatter).atStartOfDay());
        bookingInfoEntity.setToDate(LocalDate.parse(bookingInfo.getToDate(), formatter).atStartOfDay());
        bookingInfoEntity.setAadharNumber(bookingInfo.getAadharNumber());
        bookingInfoEntity.setRoomNumbers(getRoomNumbers(bookingInfo.getNumOfRooms()));
        int totalDays = (int) Math.abs(Duration.between(LocalDate.parse(bookingInfo.getToDate(), formatter).atStartOfDay(), LocalDate.parse(bookingInfo.getFromDate(), formatter).atStartOfDay()).toDays());
        bookingInfoEntity.setRoomPrice(getRoomsBookingPrice(bookingInfo.getNumOfRooms(), totalDays));
        Booking newBooking = modelMapper.map(bookingInfoEntity, Booking.class);
        newBooking.setNumOfRooms(bookingInfo.getNumOfRooms());

        return bookingRepository.save(newBooking);
    }

    @Override
    public Booking acceptPaymentDetails(PaymentInfo paymentInfo) {
        Optional<Booking> bookingOptional = bookingRepository.findById(paymentInfo.getBookingId());
        Booking booking = bookingOptional.get();
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<PaymentInfo> request = new HttpEntity<>(paymentInfo);

        int transactionId = restTemplate.postForObject(paymentUrl, request,Integer.class);

        if(transactionId != 0){
            String message = "Booking confirmed for user with aadhaar number: "
                    + booking.getAadharNumber()
                    +    "    |    "
                    + "Here are the booking details:    " + booking.toString();
            logger.info(message);
        }

        booking.setTransactionId(transactionId);
        return bookingRepository.save(booking);
    }

    private String getRoomNumbers(int noOfRooms) {
        Random rand = new Random();
        int upperBound = 100;
        List<String> numberList = new ArrayList<>();

        for (int i = 0; i < noOfRooms; i++) {
            numberList.add(String.valueOf(rand.nextInt(upperBound)));
        }
        return numberList.toString();
    }

    private int getRoomsBookingPrice(int noOfRooms, int noOfDays) {
        return 1000 * noOfRooms * noOfDays;
    }
}
