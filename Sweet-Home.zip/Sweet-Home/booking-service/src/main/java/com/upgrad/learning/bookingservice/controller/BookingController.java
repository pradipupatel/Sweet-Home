package com.upgrad.learning.bookingservice.controller;

import com.upgrad.learning.bookingservice.dto.BookingInfo;
import com.upgrad.learning.bookingservice.dto.BookingInfoEntity;
import com.upgrad.learning.bookingservice.dto.PaymentInfo;
import com.upgrad.learning.bookingservice.entities.Booking;
import com.upgrad.learning.bookingservice.service.BookingService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(value = "/hotel/booking")
public class BookingController {
    @Autowired
    private BookingService bookingService;

    @Autowired
    ModelMapper modelMapper;

    @PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity createBooking(@RequestBody BookingInfo bookingInfo) {
        Booking savedBooking = bookingService.acceptBookingDetails(bookingInfo);
        BookingInfoEntity savedBookingDto = modelMapper.map(savedBooking, BookingInfoEntity.class);
        return new ResponseEntity(savedBookingDto, HttpStatus.CREATED);
    }

    @PostMapping(value = "/{bookingId}/transaction",consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity createPayment(@RequestBody PaymentInfo paymentInfo) {
        Booking savedBooking = bookingService.acceptPaymentDetails(paymentInfo);
        BookingInfoEntity savedBookingDto = modelMapper.map(savedBooking, BookingInfoEntity.class);
        return new ResponseEntity(savedBookingDto, HttpStatus.OK);
    }
}
