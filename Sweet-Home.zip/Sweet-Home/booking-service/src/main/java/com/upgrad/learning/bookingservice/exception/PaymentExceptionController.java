package com.upgrad.learning.bookingservice.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class PaymentExceptionController {

    @ExceptionHandler(value = BookingException.class)
    public ResponseEntity<Object> exception(BookingException bookingException) {
        return new ResponseEntity<>(bookingException.toString(), HttpStatus.BAD_REQUEST);
    }
}
