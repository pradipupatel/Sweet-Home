package com.upgrad.learning.paymentservice.aspect;

import com.upgrad.learning.paymentservice.dto.PaymentInfo;
import com.upgrad.learning.paymentservice.exception.TransactionException;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class PaymentAspect {
    @Before(value = "execution(* com.upgrad.learning.paymentservice.service.PaymentServiceImpl.createTransaction(..)) and args(paymentInfo)")
    public void beforeAdvice(JoinPoint joinPoint, PaymentInfo paymentInfo){
        if(!(paymentInfo.getPaymentMode().equalsIgnoreCase("upi") || paymentInfo.getPaymentMode().equalsIgnoreCase("card"))){
            throw new TransactionException("Invalid mode of payment", HttpStatus.BAD_REQUEST.value());
        }
    }
}
