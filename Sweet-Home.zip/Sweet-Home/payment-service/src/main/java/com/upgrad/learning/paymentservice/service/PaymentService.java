package com.upgrad.learning.paymentservice.service;

import com.upgrad.learning.paymentservice.dto.PaymentInfo;
import com.upgrad.learning.paymentservice.entities.TransactionDetailsEntity;

public interface PaymentService {
    public int createTransaction(PaymentInfo paymentInfo);

    public TransactionDetailsEntity fetchPaymentDetails(int transactionId);
}
