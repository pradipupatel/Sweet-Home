package com.upgrad.learning.paymentservice.controller;

import com.upgrad.learning.paymentservice.dto.PaymentInfo;
import com.upgrad.learning.paymentservice.entities.TransactionDetailsEntity;
import com.upgrad.learning.paymentservice.service.PaymentService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(value = "/payment/transaction")
public class PaymentController {
    @Autowired
    private PaymentService paymentService;

    @Autowired
    private ModelMapper modelMapper;
    @PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity createTransaction(@RequestBody PaymentInfo paymentInfo) {
        int transactionId = paymentService.createTransaction(paymentInfo);
        return new ResponseEntity(transactionId, HttpStatus.CREATED);
    }
    @GetMapping(value="/{transactionId}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity fetchTransaction(@PathVariable int transactionId) {
        TransactionDetailsEntity transactionDetailsEntity = paymentService.fetchPaymentDetails(transactionId);
        return new ResponseEntity(transactionDetailsEntity, HttpStatus.OK);
    }

}
