package com.upgrad.learning.paymentservice.service;

import com.upgrad.learning.paymentservice.dto.PaymentInfo;
import com.upgrad.learning.paymentservice.entities.TransactionDetailsEntity;
import com.upgrad.learning.paymentservice.repository.TransactionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PaymentServiceImpl implements PaymentService{

    @Autowired
    private TransactionRepository transactionRepository;
    @Override
    public int createTransaction(PaymentInfo paymentInfo) {
        TransactionDetailsEntity transactionDetailsEntity = new TransactionDetailsEntity();
        transactionDetailsEntity.setBookingId(paymentInfo.getBookingId());
        transactionDetailsEntity.setPaymentMode(paymentInfo.getPaymentMode());
        transactionDetailsEntity.setCardNumber(paymentInfo.getCardNumber());
        transactionDetailsEntity.setUpiId(paymentInfo.getUpiId());
        TransactionDetailsEntity savedTransactionDetailsEntity =  transactionRepository.save(transactionDetailsEntity);
        return savedTransactionDetailsEntity.getTransactionId();
    }

    @Override
    public TransactionDetailsEntity fetchPaymentDetails(int transactionId) {
        return transactionRepository.findById(transactionId).get();
    }
}
