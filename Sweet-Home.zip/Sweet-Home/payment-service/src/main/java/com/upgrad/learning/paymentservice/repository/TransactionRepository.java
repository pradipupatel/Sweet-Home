package com.upgrad.learning.paymentservice.repository;

import com.upgrad.learning.paymentservice.entities.TransactionDetailsEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TransactionRepository extends JpaRepository<TransactionDetailsEntity, Integer> {
}
