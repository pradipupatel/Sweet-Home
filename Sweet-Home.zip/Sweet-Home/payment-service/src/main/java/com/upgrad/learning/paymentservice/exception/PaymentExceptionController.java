package com.upgrad.learning.paymentservice.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class PaymentExceptionController {

    @ExceptionHandler(value = TransactionException.class)
    public ResponseEntity<Object> exception(TransactionException transactionException) {
        return new ResponseEntity<>(transactionException.toString(), HttpStatus.BAD_REQUEST);
    }
}
